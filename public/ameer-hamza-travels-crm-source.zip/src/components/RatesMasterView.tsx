import React, { useState } from 'react';
import { HotelRate, VisaRate, TransportRate, VisaCompany } from '../types';
import {
  Building2,
  FileCheck2,
  Car,
  Plus,
  Search,
  Star,
  DollarSign,
  Briefcase,
  PhoneCall,
  CheckCircle,
} from 'lucide-react';

interface RatesMasterViewProps {
  hotelRates: HotelRate[];
  visaRates: VisaRate[];
  transportRates: TransportRate[];
  visaCompanies: VisaCompany[];
  onAddHotelRate: (rate: HotelRate) => void;
  onAddVisaRate: (rate: VisaRate) => void;
  onAddTransportRate: (rate: TransportRate) => void;
  onAddVisaCompany: (company: VisaCompany) => void;
  userRole: 'admin' | 'staff' | 'agent';
}

export const RatesMasterView: React.FC<RatesMasterViewProps> = ({
  hotelRates,
  visaRates,
  transportRates,
  visaCompanies,
  onAddHotelRate,
  onAddVisaRate,
  onAddTransportRate,
  onAddVisaCompany,
  userRole,
}) => {
  const [activeTab, setActiveTab] = useState<'hotels' | 'visas' | 'transport' | 'visacompanies'>('hotels');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals state
  const [isHotelModalOpen, setIsHotelModalOpen] = useState(false);
  const [isVisaModalOpen, setIsVisaModalOpen] = useState(false);
  const [isTransportModalOpen, setIsTransportModalOpen] = useState(false);
  const [isVisaCompanyModalOpen, setIsVisaCompanyModalOpen] = useState(false);

  // Forms State
  const [newHotel, setNewHotel] = useState<Partial<HotelRate>>({
    city: 'Makkah',
    hotelName: '',
    roomType: 'Quad',
    mealPlan: 'RO',
    season: 'Standard',
    buyingRateSAR: 200,
    sellingRateB2BSAR: 260,
    starRating: 4,
  });

  const [newVisa, setNewVisa] = useState<Partial<VisaRate>>({
    visaType: 'Umrah Visa 30 Days Single Entry',
    durationDays: 30,
    buyingRatePKR: 44000,
    sellingRateB2BPKR: 50000,
    processingTime: '24-48 Hours',
  });

  const [newTransport, setNewTransport] = useState<Partial<TransportRate>>({
    route: 'Jeddah Airport -> Makkah Hotel',
    vehicleType: 'Private GMC Yukon (7 Pax)',
    buyingRateSAR: 450,
    sellingRateB2BSAR: 550,
  });

  const [newVisaCo, setNewVisaCo] = useState<Partial<VisaCompany>>({
    companyName: '',
    branchCity: 'Multan',
    whatsapp: '+92 300 8632190',
    licenseNo: 'KSA-MOFA-4809',
    notes: 'Saudi Umrah Visa & MOFA Issuing Partner',
  });

  const handleCreateHotel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHotel.hotelName) return;
    onAddHotelRate({
      id: 'hr-' + Date.now(),
      city: (newHotel.city as any) || 'Makkah',
      hotelName: newHotel.hotelName,
      roomType: newHotel.roomType || 'Quad',
      mealPlan: (newHotel.mealPlan as any) || 'RO',
      season: (newHotel.season as any) || 'Standard',
      buyingRateSAR: Number(newHotel.buyingRateSAR) || 0,
      sellingRateB2BSAR: Number(newHotel.sellingRateB2BSAR) || 0,
      starRating: Number(newHotel.starRating) || 4,
    });
    setIsHotelModalOpen(false);
  };

  const handleCreateVisa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVisa.visaType) return;
    onAddVisaRate({
      id: 'vr-' + Date.now(),
      visaType: newVisa.visaType,
      durationDays: Number(newVisa.durationDays) || 30,
      buyingRatePKR: Number(newVisa.buyingRatePKR) || 0,
      sellingRateB2BPKR: Number(newVisa.sellingRateB2BPKR) || 0,
      processingTime: newVisa.processingTime || '24 Hours',
    });
    setIsVisaModalOpen(false);
  };

  const handleCreateTransport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTransport.route) return;
    onAddTransportRate({
      id: 'tr-' + Date.now(),
      route: newTransport.route,
      vehicleType: newTransport.vehicleType || 'Economy By Bus',
      buyingRateSAR: Number(newTransport.buyingRateSAR) || 0,
      sellingRateB2BSAR: Number(newTransport.sellingRateB2BSAR) || 0,
    });
    setIsTransportModalOpen(false);
  };

  const handleCreateVisaCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVisaCo.companyName) return;
    onAddVisaCompany({
      id: 'vc-' + Date.now(),
      companyName: newVisaCo.companyName,
      branchCity: newVisaCo.branchCity || 'Saudi Arabia',
      whatsapp: newVisaCo.whatsapp || '+966 50 123 4567',
      phone: newVisaCo.whatsapp || '+966 50 123 4567',
      licenseNo: newVisaCo.licenseNo || 'KSA-MOFA-GEN',
      notes: newVisaCo.notes || 'Visa Partner',
    });
    setIsVisaCompanyModalOpen(false);
  };

  const isAdmin = userRole === 'admin' || userRole === 'staff';

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-white tracking-tight">CRM Pricing & Master Data</h1>
            <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded-full uppercase">
              B2B Masters
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Manage contract rates for hotels, Umrah visas, transport routes, and Saudi Visa Companies (MOFA partners).
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-slate-800 p-1.5 rounded-xl text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('hotels')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              activeTab === 'hotels' ? 'bg-amber-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Building2 className="w-4 h-4" />
            Hotels ({hotelRates.length})
          </button>
          <button
            onClick={() => setActiveTab('visas')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              activeTab === 'visas' ? 'bg-amber-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            Visa Rates ({visaRates.length})
          </button>
          <button
            onClick={() => setActiveTab('transport')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              activeTab === 'transport' ? 'bg-amber-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Car className="w-4 h-4" />
            Transport ({transportRates.length})
          </button>
          <button
            onClick={() => setActiveTab('visacompanies')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition cursor-pointer ${
              activeTab === 'visacompanies' ? 'bg-amber-500 text-slate-950 shadow-xs' : 'text-slate-300 hover:text-white'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            Visa Companies ({visaCompanies.length})
          </button>
        </div>
      </div>

      {/* Subheader Search & Add Button */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative min-w-[280px]">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={`Search ${activeTab}...`}
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
          />
        </div>

        {isAdmin && (
          <div>
            {activeTab === 'hotels' && (
              <button
                onClick={() => setIsHotelModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add New Hotel Contract
              </button>
            )}
            {activeTab === 'visas' && (
              <button
                onClick={() => setIsVisaModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add New Visa Rate
              </button>
            )}
            {activeTab === 'transport' && (
              <button
                onClick={() => setIsTransportModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add New Transport Route
              </button>
            )}
            {activeTab === 'visacompanies' && (
              <button
                onClick={() => setIsVisaCompanyModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-xs transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Add Visa Company (Supplier)
              </button>
            )}
          </div>
        )}
      </div>

      {/* TAB 1: HOTEL RATES */}
      {activeTab === 'hotels' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-3 w-24">City</th>
                  <th className="p-3">Hotel Name</th>
                  <th className="p-3 w-28">Room Type</th>
                  <th className="p-3 w-16 text-center">Meal</th>
                  <th className="p-3 w-24 text-center">Stars</th>
                  {isAdmin && <th className="p-3 w-28 text-right">Cost (SAR)</th>}
                  <th className="p-3 w-28 text-right">B2B Rate (SAR)</th>
                  {isAdmin && <th className="p-3 w-28 text-right">Margin / Nt</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {hotelRates
                  .filter(
                    (h) =>
                      h.hotelName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      h.city.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((rate) => {
                    const margin = rate.sellingRateB2BSAR - rate.buyingRateSAR;
                    return (
                      <tr key={rate.id} className="hover:bg-amber-50/20">
                        <td className="p-3 font-semibold text-slate-900">{rate.city}</td>
                        <td className="p-3 font-medium text-slate-900">{rate.hotelName}</td>
                        <td className="p-3 text-slate-600">{rate.roomType}</td>
                        <td className="p-3 text-center font-bold text-slate-700">{rate.mealPlan}</td>
                        <td className="p-3 text-center">
                          <span className="flex items-center justify-center gap-0.5 text-amber-500">
                            {Array.from({ length: rate.starRating }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                            ))}
                          </span>
                        </td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono text-slate-500">
                            SAR {rate.buyingRateSAR}
                          </td>
                        )}
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          SAR {rate.sellingRateB2BSAR}
                        </td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono font-bold text-emerald-600">
                            +SAR {margin}
                          </td>
                        )}
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: VISA RATES */}
      {activeTab === 'visas' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-3">Visa Type & Inclusions</th>
                  <th className="p-3 w-28 text-center">Validity</th>
                  <th className="p-3 w-32 text-center">Turnaround</th>
                  {isAdmin && <th className="p-3 w-36 text-right">Cost Price (PKR)</th>}
                  <th className="p-3 w-36 text-right">B2B Price (PKR)</th>
                  {isAdmin && <th className="p-3 w-32 text-right">Gross Profit</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {visaRates
                  .filter((v) => v.visaType.toLowerCase().includes(searchTerm.toLowerCase()))
                  .map((v) => {
                    const margin = v.sellingRateB2BPKR - v.buyingRatePKR;
                    return (
                      <tr key={v.id} className="hover:bg-amber-50/20">
                        <td className="p-3 font-semibold text-slate-900">{v.visaType}</td>
                        <td className="p-3 text-center text-slate-600 font-medium">{v.durationDays} Days</td>
                        <td className="p-3 text-center text-slate-600">{v.processingTime}</td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono text-slate-500">
                            PKR {v.buyingRatePKR.toLocaleString()}
                          </td>
                        )}
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          PKR {v.sellingRateB2BPKR.toLocaleString()}
                        </td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono font-bold text-emerald-600">
                            +PKR {margin.toLocaleString()}
                          </td>
                        )}
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: TRANSPORT RATES */}
      {activeTab === 'transport' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-3">Sector / Route</th>
                  <th className="p-3 w-64">Vehicle Category</th>
                  {isAdmin && <th className="p-3 w-32 text-right">Cost (SAR)</th>}
                  <th className="p-3 w-32 text-right">B2B Rate (SAR)</th>
                  {isAdmin && <th className="p-3 w-32 text-right">Margin (SAR)</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transportRates
                  .filter(
                    (t) =>
                      t.route.toLowerCase().includes(searchTerm.toLowerCase()) ||
                      t.vehicleType.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .map((t) => {
                    const margin = t.sellingRateB2BSAR - t.buyingRateSAR;
                    return (
                      <tr key={t.id} className="hover:bg-amber-50/20">
                        <td className="p-3 font-semibold text-slate-900">{t.route}</td>
                        <td className="p-3 text-slate-700">{t.vehicleType}</td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono text-slate-500">SAR {t.buyingRateSAR}</td>
                        )}
                        <td className="p-3 text-right font-mono font-bold text-slate-900">
                          SAR {t.sellingRateB2BSAR}
                        </td>
                        {isAdmin && (
                          <td className="p-3 text-right font-mono font-bold text-emerald-600">
                            +SAR {margin}
                          </td>
                        )}
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: VISA COMPANIES (SAUDI MOFA PARTNERS) */}
      {activeTab === 'visacompanies' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-blue-50/60 border-b border-blue-100 text-xs text-blue-900">
            <span className="font-bold">Understanding Visa Companies:</span> As clarified in your workflow, Visa Companies (like <span className="font-bold">Ziafa International</span>) are Saudi MOFA providers and visa processors—<span className="underline">not</span> your clients. They appear on the top-right header of the hotel voucher, while Sub-Agents are your B2B clients. You can configure multiple Visa Companies here.
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-3">Visa Company Name</th>
                  <th className="p-3 w-36">Branch / City</th>
                  <th className="p-3 w-44">WhatsApp Contact</th>
                  <th className="p-3 w-40">KSA MOFA License</th>
                  <th className="p-3">Operational Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {visaCompanies
                  .filter((vc) => vc.companyName.toLowerCase().includes(searchTerm.toLowerCase()))
                  .map((vc) => (
                    <tr key={vc.id} className="hover:bg-amber-50/20">
                      <td className="p-3 font-bold text-blue-950 text-sm flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                        {vc.companyName}
                      </td>
                      <td className="p-3 font-medium text-slate-800">{vc.branchCity}</td>
                      <td className="p-3 font-mono font-bold text-slate-900 flex items-center gap-1.5">
                        <PhoneCall className="w-3.5 h-3.5 text-emerald-600 inline" />
                        {vc.whatsapp}
                      </td>
                      <td className="p-3 font-mono text-slate-600">{vc.licenseNo || '-'}</td>
                      <td className="p-3 text-slate-500">{vc.notes || 'Official Visa Gateway'}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD VISA COMPANY */}
      {isVisaCompanyModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-blue-700" />
              Add Visa Company (Saudi Provider)
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Add a Saudi visa company (e.g. Ziafa International, Bab Al-Umrah) that appears on voucher top-right.
            </p>

            <form onSubmit={handleCreateVisaCompany} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Company Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bab Al-Umrah Services"
                  value={newVisaCo.companyName}
                  onChange={(e) => setNewVisaCo({ ...newVisaCo, companyName: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-bold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Branch / City</label>
                <input
                  type="text"
                  placeholder="e.g. Multan / Jeddah"
                  value={newVisaCo.branchCity}
                  onChange={(e) => setNewVisaCo({ ...newVisaCo, branchCity: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">WhatsApp Number</label>
                <input
                  type="text"
                  placeholder="e.g. +92 300 8632190"
                  value={newVisaCo.whatsapp}
                  onChange={(e) => setNewVisaCo({ ...newVisaCo, whatsapp: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">KSA MOFA License #</label>
                <input
                  type="text"
                  placeholder="e.g. KSA-MOFA-480901"
                  value={newVisaCo.licenseNo}
                  onChange={(e) => setNewVisaCo({ ...newVisaCo, licenseNo: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsVisaCompanyModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-700 hover:bg-blue-600 text-white font-bold rounded-lg cursor-pointer shadow-xs"
                >
                  Save Visa Company
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
