import React from 'react';
import { UserRole, B2BAgent } from '../types';
import {
  FileText,
  PlusCircle,
  FileSpreadsheet,
  Wallet,
  Settings,
  ShieldCheck,
  Building,
  UserCheck,
  ChevronDown,
} from 'lucide-react';

interface HeaderProps {
  currentTab: 'vouchers' | 'create' | 'import' | 'ledgers' | 'rates';
  onTabChange: (tab: 'vouchers' | 'create' | 'import' | 'ledgers' | 'rates') => void;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  agents: B2BAgent[];
  currentAgent: B2BAgent;
  onAgentChange: (agentId: string) => void;
  pendingApprovalsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  userRole,
  onRoleChange,
  agents,
  currentAgent,
  onAgentChange,
  pendingApprovalsCount,
}) => {
  return (
    <header className="no-print bg-slate-950 text-white border-b border-slate-800 sticky top-0 z-40 shadow-xl">
      {/* Upper Brand & Role Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4 border-b border-slate-800/80">
        {/* Brand identity & Logo */}
        <div className="flex items-center gap-3">
          <img
            src="/assets/aistudio/WhatsApp_Image_2026-09-19_at_6.05.56_PM_e36ed21d.jpeg"
            alt="Ameer Hamza Travels & Tours"
            className="h-11 object-contain bg-white/95 rounded-lg p-1 shadow-xs"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif font-black text-lg tracking-tight text-white">
                AMEER HAMZA
              </span>
              <span className="text-amber-400 font-extrabold text-sm uppercase tracking-wider">
                Travels & Tours
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-medium">
              B2B Umrah CRM & Hotel Voucher Management Platform
            </div>
          </div>
        </div>

        {/* Tiered Role & Persona Switcher */}
        <div className="flex items-center gap-3">
          {/* Role Mode selector */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-xl p-1 text-xs">
            <span className="text-[11px] text-slate-400 font-medium px-2">Access:</span>
            
            <button
              onClick={() => onRoleChange('admin')}
              className={`flex items-center gap-1 px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                userRole === 'admin'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Admin (Approval Desk)
            </button>

            <button
              onClick={() => onRoleChange('agent')}
              className={`flex items-center gap-1 px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                userRole === 'agent'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              B2B Agent Account
            </button>
          </div>

          {/* Current Agent Switcher (when in Agent view or to filter) */}
          {userRole === 'agent' && (
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs">
              <span className="text-[11px] text-amber-400 font-semibold">Agent:</span>
              <select
                value={currentAgent.id}
                onChange={(e) => onAgentChange(e.target.value)}
                className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
              >
                {agents.map((ag) => (
                  <option key={ag.id} value={ag.id} className="bg-slate-900 text-white">
                    {ag.companyName} ({ag.city})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between overflow-x-auto">
        <nav className="flex space-x-1 py-2 text-xs font-semibold">
          <button
            onClick={() => onTabChange('vouchers')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              currentTab === 'vouchers'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            Vouchers
            {pendingApprovalsCount > 0 && userRole === 'admin' && (
              <span className="bg-rose-500 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full">
                {pendingApprovalsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onTabChange('create')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              currentTab === 'create'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            Create Voucher (6+ Sectors)
          </button>

          <button
            onClick={() => onTabChange('import')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              currentTab === 'import'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            Import Excel / Nusuk
          </button>

          <button
            onClick={() => onTabChange('ledgers')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              currentTab === 'ledgers'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4" />
            B2B Ledgers & Accounts
          </button>

          <button
            onClick={() => onTabChange('rates')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition cursor-pointer ${
              currentTab === 'rates'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:bg-slate-900 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            CRM Rates Master (Hotels & Visas)
          </button>
        </nav>

        {/* Status indicator */}
        <div className="hidden lg:flex items-center gap-2 text-[11px] text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Ameer Hamza Central Server Active</span>
        </div>
      </div>
    </header>
  );
};
