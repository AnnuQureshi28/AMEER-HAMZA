import React, { useState, useEffect } from 'react';
import {
  Voucher,
  Mutamer,
  HotelSector,
  TransportSector,
  B2BAgent,
  VisaCompany,
  PilgrimGroup,
  GroundContact,
  PaxType,
} from '../types';
import { calculateNights, summarizePax } from '../utils/voucherUtils';
import { DEFAULT_GROUND_CONTACTS } from '../data/initialData';
import {
  Building2,
  Car,
  Plane,
  Users,
  Plus,
  Trash2,
  FileSpreadsheet,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Briefcase,
  Layers,
} from 'lucide-react';

interface VoucherCreatorProps {
  currentAgent: B2BAgent;
  userRole: 'admin' | 'staff' | 'agent';
  allAgents: B2BAgent[];
  visaCompanies: VisaCompany[];
  groups: PilgrimGroup[];
  prefilledGroup?: PilgrimGroup | null;
  onSave: (voucher: Voucher) => void;
  onCancel: () => void;
  onOpenImporter: () => void;
}

export const VoucherCreator: React.FC<VoucherCreatorProps> = ({
  currentAgent,
  userRole,
  allAgents,
  visaCompanies,
  groups,
  prefilledGroup,
  onSave,
  onCancel,
  onOpenImporter,
}) => {
  // Sub-Agent (Client) Selection
  const [selectedAgentId, setSelectedAgentId] = useState<string>(
    prefilledGroup?.subAgentId || currentAgent.id
  );
  // Visa Company Selection (e.g. Ziafa International, Bab Al-Umrah)
  const [selectedVisaCompanyId, setSelectedVisaCompanyId] = useState<string>(
    prefilledGroup?.visaCompanyId || visaCompanies[0]?.id || ''
  );

  const activeAgent = allAgents.find((a) => a.id === selectedAgentId) || currentAgent;
  const activeVisaCompany =
    visaCompanies.find((v) => v.id === selectedVisaCompanyId) || visaCompanies[0];

  // Voucher Numbers & Headers
  const [voucherNo, setVoucherNo] = useState<string>(
    'UB-' + Math.floor(100000 + Math.random() * 900000)
  );
  const [manualNo, setManualNo] = useState<string>('M G H ' + Math.floor(10 + Math.random() * 90));
  const [voucherDate, setVoucherDate] = useState<string>('01/11/26');
  const [packageType, setPackageType] = useState<string>('20 Standard');
  const [groupNo, setGroupNo] = useState<string>(prefilledGroup?.groupNo || '1000');
  const [groupName, setGroupName] = useState<string>(
    prefilledGroup?.groupName || 'AMEERHAMZAONLYACC'
  );
  const [familyHead, setFamilyHead] = useState<string>('');

  // Mutamers / Pilgrims
  const [mutamers, setMutamers] = useState<Mutamer[]>(
    prefilledGroup?.mutamers || [
      {
        id: 'm-init-1',
        sno: 1,
        passportNo: 'BA6925931',
        firstName: 'FIAZ',
        familyName: 'HUSSAIN',
        mutamerName: 'FIAZ HUSSAIN',
        gender: 'M',
        paxType: 'Adult',
        bed: 'Yes',
        mofaNo: '4810029311',
        grpNo: '1000',
        visaNo: '99201101',
        pnr: 'PK760',
        birthDate: '01/01/1950',
      },
      {
        id: 'm-init-2',
        sno: 2,
        passportNo: 'BF8526352',
        firstName: 'GHULAM',
        familyName: 'JAFFAR',
        mutamerName: 'GHULAM JAFFAR',
        gender: 'M',
        paxType: 'Adult',
        bed: 'Yes',
        mofaNo: '4810029312',
        grpNo: '1000',
        visaNo: '99201102',
        pnr: 'PK760',
        birthDate: '01/01/1962',
      },
      {
        id: 'm-init-3',
        sno: 3,
        passportNo: 'KG6896784',
        firstName: 'IQBAL',
        familyName: 'HUSSAIN',
        mutamerName: 'IQBAL HUSSAIN',
        gender: 'M',
        paxType: 'Adult',
        bed: 'Yes',
        mofaNo: '4810029313',
        grpNo: '1000',
        visaNo: '99201103',
        pnr: 'PK760',
        birthDate: '12/04/1986',
      },
    ]
  );

  // Accommodations (6 Sectors standard)
  const [accommodations, setAccommodations] = useState<HotelSector[]>([
    {
      id: 'acc-sec-1',
      city: 'Makkah',
      hotelName: 'Swissotel Al Maqam Clock Tower',
      view: 'Kaaba View',
      meal: 'BB',
      confNo: 'MK-901',
      roomType: 'Sharing (Gender)',
      checkin: '01-11-26',
      checkout: '06-11-26',
      nights: 5,
      b2bRatePerNight: 850,
    },
    {
      id: 'acc-sec-2',
      city: 'Medinah',
      hotelName: 'Anwar Al Madinah Movenpick',
      view: 'Haram View',
      meal: 'BB',
      confNo: 'MD-802',
      roomType: 'Sharing (Gender)',
      checkin: '06-11-26',
      checkout: '11-11-26',
      nights: 5,
      b2bRatePerNight: 720,
    },
    {
      id: 'acc-sec-3',
      city: 'Medinah',
      hotelName: 'Al Aqeeq Golden Tulip Madinah',
      view: 'City View',
      meal: 'RO',
      confNo: 'MD-803',
      roomType: 'Sharing (Gender)',
      checkin: '11-11-26',
      checkout: '15-11-26',
      nights: 4,
      b2bRatePerNight: 350,
    },
    {
      id: 'acc-sec-4',
      city: 'Makkah',
      hotelName: 'Emaar Elite Makkah',
      view: 'Standard',
      meal: 'RO',
      confNo: 'MK-904',
      roomType: 'Sharing (Gender)',
      checkin: '15-11-26',
      checkout: '20-11-26',
      nights: 5,
      b2bRatePerNight: 240,
    },
    {
      id: 'acc-sec-5',
      city: 'Makkah',
      hotelName: 'Pullman Zamzam Makkah',
      view: 'Standard',
      meal: 'RO',
      confNo: 'MK-905',
      roomType: 'Sharing (Gender)',
      checkin: '20-11-26',
      checkout: '25-11-26',
      nights: 5,
      b2bRatePerNight: 780,
    },
    {
      id: 'acc-sec-6',
      city: 'Jeddah',
      hotelName: 'Radisson Blu Corniche Jeddah',
      view: 'Sea View',
      meal: 'BB',
      confNo: 'JD-906',
      roomType: 'Double',
      checkin: '25-11-26',
      checkout: '28-11-26',
      nights: 3,
      b2bRatePerNight: 520,
    },
  ]);

  // Transport Sectors
  const [transportServices, setTransportServices] = useState<TransportSector[]>([
    {
      id: 'tr-1',
      travelDate: '01-11-26',
      transporter: 'Company Transport',
      vehicleType: 'Private GMC Yukon',
      routeDescription: 'Jeddah Airport -> Makkah Hotel (Arrival Transfer)',
      b2bPrice: 550,
    },
    {
      id: 'tr-2',
      travelDate: '04-11-26',
      transporter: 'Company Transport',
      vehicleType: 'Toyota HiAce (14 Seater)',
      routeDescription: 'Makkah Ziyarat (Jabal Al-Noor, Mina, Arafat, Muzdalifah)',
      b2bPrice: 350,
    },
    {
      id: 'tr-3',
      travelDate: '06-11-26',
      transporter: 'Haramain High Speed Rail',
      vehicleType: 'Bullet Train (Haramain)',
      routeDescription: 'Makkah Station -> Madinah Station',
      b2bPrice: 600,
    },
    {
      id: 'tr-4',
      travelDate: '09-11-26',
      transporter: 'Company Transport',
      vehicleType: 'Toyota HiAce (14 Seater)',
      routeDescription: 'Madinah Ziyarat (Masjid Quba, Mount Uhud, Qiblatain)',
      b2bPrice: 350,
    },
    {
      id: 'tr-5',
      travelDate: '28-11-26',
      transporter: 'Company Transport',
      vehicleType: 'Private GMC Yukon',
      routeDescription: 'Jeddah Hotel -> King Abdulaziz Airport (Departure Transfer)',
      b2bPrice: 200,
    },
  ]);

  // Flights
  const [depFlight, setDepFlight] = useState({
    flightNo: 'SV-723',
    sector: 'ISB-JED',
    depTime: '01-NOV 10:30',
    arrTime: '01-NOV 14:20',
  });
  const [arrFlight, setArrFlight] = useState({
    flightNo: 'SV-726',
    sector: 'JED-ISB',
    depTime: '28-NOV 18:10',
    arrTime: '29-NOV 00:50',
  });

  const [specialInstructions, setSpecialInstructions] = useState<string>(
    'Hotel check-in at 16:00. Report to lobby 5 hours prior to airport departure. Keep original passports handy for bus check.'
  );

  const [groundContacts, setGroundContacts] = useState<GroundContact[]>(DEFAULT_GROUND_CONTACTS);

  // Set family head default
  useEffect(() => {
    if (!familyHead && mutamers.length > 0) {
      setFamilyHead(mutamers[0].mutamerName);
    }
  }, [mutamers, familyHead]);

  // Handle switching to a pre-existing imported group
  const handleSelectExistingGroup = (groupId: string) => {
    const selected = groups.find((g) => g.id === groupId);
    if (!selected) return;

    setSelectedAgentId(selected.subAgentId);
    setSelectedVisaCompanyId(selected.visaCompanyId);
    setGroupNo(selected.groupNo);
    setGroupName(selected.groupName);
    setMutamers(selected.mutamers);
    if (selected.mutamers.length > 0) {
      setFamilyHead(selected.mutamers[0].mutamerName);
    }
  };

  // Mutamers handlers
  const addMutamerRow = () => {
    const sno = mutamers.length + 1;
    setMutamers([
      ...mutamers,
      {
        id: 'm-' + Date.now(),
        sno,
        passportNo: '',
        firstName: '',
        familyName: '',
        mutamerName: '',
        gender: 'M',
        paxType: 'Adult',
        bed: 'Yes',
        mofaNo: '4809' + Math.floor(100000 + Math.random() * 900000),
        grpNo: groupNo || '1000',
        visaNo: '',
        pnr: depFlight.flightNo,
      },
    ]);
  };

  const updateMutamer = (index: number, field: keyof Mutamer, value: any) => {
    const updated = [...mutamers];
    updated[index] = { ...updated[index], [field]: value };
    if (field === 'firstName' || field === 'familyName') {
      const fName = field === 'firstName' ? value : updated[index].firstName;
      const lName = field === 'familyName' ? value : updated[index].familyName;
      updated[index].mutamerName = `${fName} ${lName}`.trim();
    }
    setMutamers(updated);
  };

  const removeMutamer = (index: number) => {
    const updated = mutamers.filter((_, i) => i !== index).map((m, idx) => ({ ...m, sno: idx + 1 }));
    setMutamers(updated);
  };

  // Accommodations handlers
  const addAccommodationSector = () => {
    const lastSector = accommodations[accommodations.length - 1];
    const defaultCity = lastSector?.city === 'Makkah' ? 'Medinah' : 'Makkah';
    setAccommodations([
      ...accommodations,
      {
        id: 'acc-' + Date.now(),
        city: defaultCity,
        hotelName: defaultCity === 'Makkah' ? 'Emaar Elite Makkah' : 'Anwar Al Madinah Movenpick',
        view: 'Standard',
        meal: 'RO',
        confNo: 'CONF-' + Math.floor(1000 + Math.random() * 9000),
        roomType: 'Sharing (Gender)',
        checkin: lastSector?.checkout || '01-11-26',
        checkout: '07-11-26',
        nights: 6,
        b2bRatePerNight: 240,
      },
    ]);
  };

  const updateAccommodation = (index: number, field: keyof HotelSector, value: any) => {
    const updated = [...accommodations];
    updated[index] = { ...updated[index], [field]: value };

    if (field === 'checkin' || field === 'checkout') {
      const inDate = field === 'checkin' ? value : updated[index].checkin;
      const outDate = field === 'checkout' ? value : updated[index].checkout;
      updated[index].nights = calculateNights(inDate, outDate);
    }
    setAccommodations(updated);
  };

  const removeAccommodation = (index: number) => {
    setAccommodations(accommodations.filter((_, i) => i !== index));
  };

  // Preset 6 Sectors Quick Template
  const loadSixSectorsTemplate = () => {
    setAccommodations([
      { id: 's1', city: 'Makkah', hotelName: 'Swissotel Al Maqam Clock Tower', view: 'Kaaba View', meal: 'BB', confNo: 'MK-101', roomType: 'Sharing (Gender)', checkin: '01-11-26', checkout: '06-11-26', nights: 5, b2bRatePerNight: 850 },
      { id: 's2', city: 'Medinah', hotelName: 'Anwar Al Madinah Movenpick', view: 'Haram View', meal: 'BB', confNo: 'MD-202', roomType: 'Sharing (Gender)', checkin: '06-11-26', checkout: '11-11-26', nights: 5, b2bRatePerNight: 720 },
      { id: 's3', city: 'Medinah', hotelName: 'Al Aqeeq Golden Tulip', view: 'City View', meal: 'RO', confNo: 'MD-303', roomType: 'Sharing (Gender)', checkin: '11-11-26', checkout: '16-11-26', nights: 5, b2bRatePerNight: 350 },
      { id: 's4', city: 'Makkah', hotelName: 'Emaar Elite Al Aziziyah', view: 'Standard', meal: 'RO', confNo: 'MK-404', roomType: 'Sharing (Gender)', checkin: '16-11-26', checkout: '21-11-26', nights: 5, b2bRatePerNight: 240 },
      { id: 's5', city: 'Makkah', hotelName: 'Pullman Zamzam Makkah', view: 'Haram View', meal: 'HB', confNo: 'MK-505', roomType: 'Sharing (Gender)', checkin: '21-11-26', checkout: '25-11-26', nights: 4, b2bRatePerNight: 780 },
      { id: 's6', city: 'Jeddah', hotelName: 'Radisson Blu Corniche Jeddah', view: 'Sea View', meal: 'BB', confNo: 'JD-606', roomType: 'Double', checkin: '25-11-26', checkout: '28-11-26', nights: 3, b2bRatePerNight: 520 },
    ]);
  };

  // Transport handlers
  const addTransportSector = () => {
    setTransportServices([
      ...transportServices,
      {
        id: 'tr-' + Date.now(),
        travelDate: '01-11-26',
        transporter: 'Company Transport',
        vehicleType: 'Toyota HiAce (14 Seater)',
        routeDescription: 'Holy Sites Sightseeing (Ziyarat)',
        b2bPrice: 350,
      },
    ]);
  };

  const updateTransport = (index: number, field: keyof TransportSector, value: any) => {
    const updated = [...transportServices];
    updated[index] = { ...updated[index], [field]: value };
    setTransportServices(updated);
  };

  const removeTransport = (index: number) => {
    setTransportServices(transportServices.filter((_, i) => i !== index));
  };

  // Calculations
  const paxStats = summarizePax(mutamers);
  const totalNights = accommodations.reduce((s, a) => s + (Number(a.nights) || 0), 0);
  const estimatedHotelTotal = accommodations.reduce(
    (s, a) => s + (Number(a.nights) || 0) * (Number(a.b2bRatePerNight) || 200),
    0
  );
  const estimatedTransportTotal = transportServices.reduce(
    (s, t) => s + (Number(t.b2bPrice) || 0),
    0
  );
  const estimatedVisaTotal = mutamers.length * 450;
  const grandTotalSAR = estimatedHotelTotal + estimatedTransportTotal + estimatedVisaTotal;

  // Handle saving
  const handleSave = (statusToSave: 'draft' | 'pending' | 'approved') => {
    if (!familyHead.trim() && mutamers.length > 0) {
      setFamilyHead(mutamers[0].mutamerName || 'Group Head');
    }

    const newVoucher: Voucher = {
      id: 'v-' + Date.now(),
      voucherNo: voucherNo.trim() || 'UB-' + Math.floor(100000 + Math.random() * 900000),
      manualNo: manualNo.trim() || 'M G H ' + Math.floor(10 + Math.random() * 90),
      status: statusToSave,
      voucherDate,
      packageType,
      familyHead: familyHead.trim() || (mutamers[0] ? mutamers[0].mutamerName : 'Mutamer Head'),
      groupNo,
      groupName,
      agentId: activeAgent.id,
      agentName: activeAgent.name,
      agentCompany: activeAgent.companyName,
      agentCity: activeAgent.city,
      agentWhatsapp: activeAgent.whatsapp,
      visaCompanyId: activeVisaCompany.id,
      visaCompanyName: activeVisaCompany.companyName,
      visaCompanyCity: activeVisaCompany.branchCity,
      visaCompanyWhatsapp: activeVisaCompany.whatsapp,
      mutamers,
      paxCountText: paxStats.paxText,
      accommodations,
      transportServices,
      flights: {
        departure: depFlight,
        arrival: arrFlight,
      },
      specialInstructions,
      groundContacts,
      financials: {
        hotelTotal: estimatedHotelTotal,
        transportTotal: estimatedTransportTotal,
        visaTotal: estimatedVisaTotal,
        grandTotal: grandTotalSAR,
        ledgerPosted: statusToSave === 'approved',
      },
      approvedBy:
        statusToSave === 'approved'
          ? 'Ameer Hamza Travels Central Ops (Direct Auth)'
          : undefined,
      approvedDate: statusToSave === 'approved' ? new Date().toLocaleDateString() : undefined,
      securityHash: 'ah-' + Math.random().toString(36).substring(2, 12).toUpperCase(),
      createdAt: new Date().toISOString(),
    };

    onSave(newVoucher);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8 animate-in fade-in duration-200">
      {/* Title Bar */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-white tracking-tight">Create B2B Hotel Voucher</h1>
            <span className="text-xs bg-amber-500 text-slate-950 font-black px-2.5 py-0.5 rounded-full uppercase">
              6+ Hotel Sectors & Transport
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Group #{groupNo} ({groupName}) • Client: <span className="text-amber-400 font-semibold">{activeAgent.companyName}</span> • Visa Co: <span className="text-blue-300 font-semibold">{activeVisaCompany.companyName}</span>
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
          >
            Cancel
          </button>

          {userRole === 'agent' ? (
            <>
              <button
                onClick={() => handleSave('draft')}
                className="px-4 py-2.5 text-xs font-bold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow-sm transition cursor-pointer"
              >
                Save as Draft Voucher
              </button>
              <button
                onClick={() => handleSave('pending')}
                className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-sm transition cursor-pointer flex items-center gap-2"
              >
                Submit to Ameer Hamza for Approval
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => handleSave('draft')}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
              >
                Save as Draft
              </button>
              <button
                onClick={() => handleSave('approved')}
                className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-sm transition cursor-pointer flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Issue & Approve Voucher
              </button>
            </>
          )}
        </div>
      </div>

      {/* QUICK LOAD FROM EXISTING IMPORTED GROUPS */}
      <div className="bg-amber-50/70 border border-amber-200 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Layers className="w-5 h-5 text-amber-600 shrink-0" />
          <div>
            <div className="text-xs font-bold text-amber-950">
              Select an Imported Group or Import New Excel File:
            </div>
            <div className="text-[11px] text-amber-800">
              Pre-fills all mutamers, beds, sub-agent client, and visa company automatically.
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <select
            onChange={(e) => handleSelectExistingGroup(e.target.value)}
            className="border border-amber-300 rounded-xl px-3 py-1.5 text-xs bg-white font-semibold text-slate-800 cursor-pointer shadow-xs"
          >
            <option value="">-- Choose Existing Group ({groups.length} Available) --</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                Grp #{g.groupNo} - {g.groupName} ({g.subAgentCompany} / {g.visaCompanyName})
              </option>
            ))}
          </select>

          <button
            onClick={onOpenImporter}
            className="px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition cursor-pointer flex items-center gap-1.5 shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            + Import New Excel File
          </button>
        </div>
      </div>

      {/* SECTION 1: HEADER & ENTITY ASSIGNMENTS */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2">
          1. Agency, Sub-Agent Client & Visa Company Parameters
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          {/* Sub-Agent (Client) */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Sub-Agent Client (Travel Agency)
            </label>
            <select
              value={selectedAgentId}
              onChange={(e) => setSelectedAgentId(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 bg-slate-50 font-semibold focus:bg-white"
            >
              {allAgents.map((ag) => (
                <option key={ag.id} value={ag.id}>
                  {ag.companyName} ({ag.city})
                </option>
              ))}
            </select>
          </div>

          {/* Visa Company (Right side of voucher) */}
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Visa Company (Right Header)
            </label>
            <select
              value={selectedVisaCompanyId}
              onChange={(e) => setSelectedVisaCompanyId(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 bg-slate-50 font-bold text-blue-900 focus:bg-white"
            >
              {visaCompanies.map((vc) => (
                <option key={vc.id} value={vc.id}>
                  {vc.companyName} ({vc.branchCity})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Group Number (From Excel)</label>
            <input
              type="text"
              value={groupNo}
              onChange={(e) => setGroupNo(e.target.value)}
              placeholder="e.g. 1000"
              className="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Group Name (From Excel)</label>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="e.g. AMEERHAMZAONLYACC"
              className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-900 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Voucher Number</label>
            <input
              type="text"
              value={voucherNo}
              onChange={(e) => setVoucherNo(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Manual Reference No</label>
            <input
              type="text"
              value={manualNo}
              onChange={(e) => setManualNo(e.target.value)}
              placeholder="e.g. M G H 20"
              className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-900 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Voucher Date</label>
            <input
              type="text"
              value={voucherDate}
              onChange={(e) => setVoucherDate(e.target.value)}
              placeholder="DD/MM/YY"
              className="w-full border border-slate-300 rounded-lg p-2 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Package Name / Type</label>
            <input
              type="text"
              value={packageType}
              onChange={(e) => setPackageType(e.target.value)}
              placeholder="e.g. 20 Standard"
              className="w-full border border-slate-300 rounded-lg p-2 bg-slate-50 focus:bg-white"
            />
          </div>
        </div>

        <div>
          <label className="font-bold text-slate-700 block mb-1 text-xs">Family Head Name</label>
          <input
            type="text"
            value={familyHead}
            onChange={(e) => setFamilyHead(e.target.value)}
            placeholder="e.g. Fiaz Hussain or Zahra Fatima Abid Latif"
            className="w-full border border-slate-300 rounded-lg p-2 font-semibold text-slate-900 text-xs bg-slate-50 focus:bg-white"
          />
        </div>
      </div>

      {/* SECTION 2: MUTAMERS / PILGRIMS TABLE */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Users className="w-4 h-4 text-amber-600" />
              2. Mutamers / Pilgrims in this Group ({mutamers.length})
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              PAX Breakdown: <span className="font-semibold text-slate-800">{paxStats.paxText}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenImporter}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 border border-amber-300 text-xs font-bold transition cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-600" />
              Import Excel / CSV
            </button>
            <button
              onClick={addMutamerRow}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Pilgrim
            </button>
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
              <tr>
                <th className="p-2 w-8 text-center">#</th>
                <th className="p-2 w-28">Passport No</th>
                <th className="p-2">First Name</th>
                <th className="p-2">Family / Last Name</th>
                <th className="p-2 w-14 text-center">Gender</th>
                <th className="p-2 w-20">Pax Type</th>
                <th className="p-2 w-14 text-center">Bed</th>
                <th className="p-2 w-28">MOFA #</th>
                <th className="p-2 w-24">Visa #</th>
                <th className="p-2 w-20">PNR</th>
                <th className="p-2 w-8 text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mutamers.map((m, idx) => (
                <tr key={m.id || idx} className="hover:bg-slate-50/60">
                  <td className="p-2 text-center text-slate-500 font-semibold">{idx + 1}</td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.passportNo}
                      onChange={(e) => updateMutamer(idx, 'passportNo', e.target.value)}
                      placeholder="Passport #"
                      className="w-full border border-slate-200 rounded px-2 py-1 font-mono uppercase text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.firstName}
                      onChange={(e) => updateMutamer(idx, 'firstName', e.target.value)}
                      placeholder="First Name"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.familyName}
                      onChange={(e) => updateMutamer(idx, 'familyName', e.target.value)}
                      placeholder="Family Name"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1 text-center">
                    <select
                      value={m.gender}
                      onChange={(e) => updateMutamer(idx, 'gender', e.target.value)}
                      className="border border-slate-200 rounded px-1 py-1 text-xs"
                    >
                      <option value="M">M</option>
                      <option value="F">F</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <select
                      value={m.paxType}
                      onChange={(e) => updateMutamer(idx, 'paxType', e.target.value as PaxType)}
                      className="w-full border border-slate-200 rounded px-1 py-1 text-xs"
                    >
                      <option value="Adult">Adult</option>
                      <option value="Child">Child</option>
                      <option value="Infant">Infant</option>
                    </select>
                  </td>
                  <td className="p-1 text-center">
                    <select
                      value={m.bed}
                      onChange={(e) => updateMutamer(idx, 'bed', e.target.value)}
                      className="border border-slate-200 rounded px-1 py-1 text-xs"
                    >
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.mofaNo}
                      onChange={(e) => updateMutamer(idx, 'mofaNo', e.target.value)}
                      placeholder="MOFA"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.visaNo}
                      onChange={(e) => updateMutamer(idx, 'visaNo', e.target.value)}
                      placeholder="Visa #"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={m.pnr}
                      onChange={(e) => updateMutamer(idx, 'pnr', e.target.value)}
                      placeholder="PNR"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs"
                    />
                  </td>
                  <td className="p-1 text-center">
                    {mutamers.length > 1 && (
                      <button
                        onClick={() => removeMutamer(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition cursor-pointer"
                        title="Remove passenger"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 3: ACCOMMODATION (6+ SECTORS READY) */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-600" />
              3. Accommodation Sectors ({accommodations.length} Sectors Active)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports 6 or more flexible stay sectors across Makkah, Madinah, and Jeddah. Total Nights:{' '}
              <span className="font-bold text-slate-900">{totalNights} Nights</span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadSixSectorsTemplate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-semibold transition cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Load 6-Sector Standard Template
            </button>
            <button
              onClick={addAccommodationSector}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Hotel Sector
            </button>
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
              <tr>
                <th className="p-2 w-8 text-center">Sec</th>
                <th className="p-2 w-24">City</th>
                <th className="p-2">Hotel Name</th>
                <th className="p-2 w-20">View</th>
                <th className="p-2 w-16">Meal</th>
                <th className="p-2 w-24">Conf #</th>
                <th className="p-2 w-32">Room Type</th>
                <th className="p-2 w-24">Checkin</th>
                <th className="p-2 w-24">Checkout</th>
                <th className="p-2 w-14 text-center">Nights</th>
                <th className="p-2 w-20">B2B/Nt</th>
                <th className="p-2 w-8 text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {accommodations.map((acc, idx) => (
                <tr key={acc.id || idx} className="hover:bg-slate-50/60">
                  <td className="p-2 text-center font-bold text-slate-500">{idx + 1}</td>
                  <td className="p-1">
                    <select
                      value={acc.city}
                      onChange={(e) => updateAccommodation(idx, 'city', e.target.value)}
                      className="w-full border border-slate-200 rounded px-1.5 py-1 text-xs font-semibold"
                    >
                      <option value="Makkah">Makkah</option>
                      <option value="Medinah">Medinah</option>
                      <option value="Jeddah">Jeddah</option>
                      <option value="Taif">Taif</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={acc.hotelName}
                      onChange={(e) => updateAccommodation(idx, 'hotelName', e.target.value)}
                      placeholder="Hotel Name"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs font-medium"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={acc.view}
                      onChange={(e) => updateAccommodation(idx, 'view', e.target.value)}
                      placeholder="View"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <select
                      value={acc.meal}
                      onChange={(e) => updateAccommodation(idx, 'meal', e.target.value)}
                      className="w-full border border-slate-200 rounded px-1 py-1 text-xs font-bold"
                    >
                      <option value="RO">RO</option>
                      <option value="BB">BB</option>
                      <option value="HB">HB</option>
                      <option value="FB">FB</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={acc.confNo}
                      onChange={(e) => updateAccommodation(idx, 'confNo', e.target.value)}
                      placeholder="Conf #"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <select
                      value={acc.roomType}
                      onChange={(e) => updateAccommodation(idx, 'roomType', e.target.value)}
                      className="w-full border border-slate-200 rounded px-1.5 py-1 text-xs"
                    >
                      <option value="Sharing (Gender)">Sharing (Gender)</option>
                      <option value="Quad">Quad Room (4 Beds)</option>
                      <option value="Triple">Triple Room (3 Beds)</option>
                      <option value="Double">Double Room (2 Beds)</option>
                      <option value="Single">Single Room</option>
                      <option value="Executive Suite">Executive Suite</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={acc.checkin}
                      onChange={(e) => updateAccommodation(idx, 'checkin', e.target.value)}
                      placeholder="DD-MM-YY"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs text-center"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={acc.checkout}
                      onChange={(e) => updateAccommodation(idx, 'checkout', e.target.value)}
                      placeholder="DD-MM-YY"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 font-mono text-xs text-center"
                    />
                  </td>
                  <td className="p-1 text-center font-bold text-slate-900">{acc.nights}</td>
                  <td className="p-1">
                    <input
                      type="number"
                      value={acc.b2bRatePerNight || 0}
                      onChange={(e) =>
                        updateAccommodation(idx, 'b2bRatePerNight', Number(e.target.value))
                      }
                      placeholder="SAR"
                      className="w-full border border-slate-200 rounded px-1 py-1 text-xs text-right"
                    />
                  </td>
                  <td className="p-1 text-center">
                    {accommodations.length > 1 && (
                      <button
                        onClick={() => removeAccommodation(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1 rounded transition cursor-pointer"
                        title="Delete sector"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 4: TRANSPORT & SERVICES SECTORS */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Car className="w-4 h-4 text-amber-600" />
              4. Transport Sectors & Sightseeing (Ziyarat)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Airport transfers, high-speed rail, and Makkah/Madinah holy ziyarat arrangements.
            </p>
          </div>

          <button
            onClick={addTransportSector}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Transport Sector
          </button>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200 text-[11px]">
              <tr>
                <th className="p-2 w-8 text-center">#</th>
                <th className="p-2 w-28">Travel Date</th>
                <th className="p-2 w-48">Transporter</th>
                <th className="p-2 w-48">Vehicle Type</th>
                <th className="p-2">Route / Sector Description</th>
                <th className="p-2 w-24">B2B Rate (SAR)</th>
                <th className="p-2 w-8 text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transportServices.map((tr, idx) => (
                <tr key={tr.id || idx} className="hover:bg-slate-50/60">
                  <td className="p-2 text-center text-slate-500 font-semibold">{idx + 1}</td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={tr.travelDate}
                      onChange={(e) => updateTransport(idx, 'travelDate', e.target.value)}
                      placeholder="DD-MM-YY"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={tr.transporter}
                      onChange={(e) => updateTransport(idx, 'transporter', e.target.value)}
                      placeholder="Transporter"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <select
                      value={tr.vehicleType}
                      onChange={(e) => updateTransport(idx, 'vehicleType', e.target.value)}
                      className="w-full border border-slate-200 rounded px-1.5 py-1 text-xs"
                    >
                      <option value="Economy By Bus">Economy By Bus</option>
                      <option value="Private GMC Yukon">Private GMC Yukon (7 Seater)</option>
                      <option value="Toyota HiAce (14 Seater)">Toyota HiAce (14 Seater)</option>
                      <option value="VIP Coaster (30 Seater)">VIP Coaster (30 Seater)</option>
                      <option value="Bullet Train (Haramain)">Bullet Train (Haramain)</option>
                      <option value="Private Sedan">Private Sedan</option>
                    </select>
                  </td>
                  <td className="p-1">
                    <input
                      type="text"
                      value={tr.routeDescription}
                      onChange={(e) => updateTransport(idx, 'routeDescription', e.target.value)}
                      placeholder="Route description"
                      className="w-full border border-slate-200 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="p-1">
                    <input
                      type="number"
                      value={tr.b2bPrice || 0}
                      onChange={(e) => updateTransport(idx, 'b2bPrice', Number(e.target.value))}
                      placeholder="SAR"
                      className="w-full border border-slate-200 rounded px-1.5 py-1 text-xs text-right"
                    />
                  </td>
                  <td className="p-1 text-center">
                    <button
                      onClick={() => removeTransport(idx)}
                      className="text-slate-400 hover:text-rose-600 p-1 rounded transition cursor-pointer"
                      title="Remove transport"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 5: FLIGHT DETAILS & ON-GROUND LOGISTICS */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider border-b border-slate-100 pb-2 flex items-center gap-2">
          <Plane className="w-4 h-4 text-amber-600" />
          5. Flight Itinerary & Special Instructions
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Departure Flight (Pakistan to KSA)
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Flight Number</label>
                <input
                  type="text"
                  value={depFlight.flightNo}
                  onChange={(e) => setDepFlight({ ...depFlight, flightNo: e.target.value })}
                  placeholder="e.g. SV-723"
                  className="w-full border border-slate-300 rounded p-1.5 font-bold bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Sector</label>
                <input
                  type="text"
                  value={depFlight.sector}
                  onChange={(e) => setDepFlight({ ...depFlight, sector: e.target.value })}
                  placeholder="e.g. ISB-JED"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Departure Time</label>
                <input
                  type="text"
                  value={depFlight.depTime}
                  onChange={(e) => setDepFlight({ ...depFlight, depTime: e.target.value })}
                  placeholder="01-NOV 10:30"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Arrival Time</label>
                <input
                  type="text"
                  value={depFlight.arrTime}
                  onChange={(e) => setDepFlight({ ...depFlight, arrTime: e.target.value })}
                  placeholder="01-NOV 14:20"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
            </div>
          </div>

          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Arrival Flight (KSA to Pakistan)
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Flight Number</label>
                <input
                  type="text"
                  value={arrFlight.flightNo}
                  onChange={(e) => setArrFlight({ ...arrFlight, flightNo: e.target.value })}
                  placeholder="e.g. SV-726"
                  className="w-full border border-slate-300 rounded p-1.5 font-bold bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Sector</label>
                <input
                  type="text"
                  value={arrFlight.sector}
                  onChange={(e) => setArrFlight({ ...arrFlight, sector: e.target.value })}
                  placeholder="e.g. JED-ISB"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Departure Time</label>
                <input
                  type="text"
                  value={arrFlight.depTime}
                  onChange={(e) => setArrFlight({ ...arrFlight, depTime: e.target.value })}
                  placeholder="28-NOV 18:10"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
              <div>
                <label className="text-slate-600 font-semibold block mb-1">Arrival Time</label>
                <input
                  type="text"
                  value={arrFlight.arrTime}
                  onChange={(e) => setArrFlight({ ...arrFlight, arrTime: e.target.value })}
                  placeholder="29-NOV 00:50"
                  className="w-full border border-slate-300 rounded p-1.5 bg-white"
                />
              </div>
            </div>
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-700 block mb-1">
            Special Instructions for Mutamers
          </label>
          <textarea
            value={specialInstructions}
            onChange={(e) => setSpecialInstructions(e.target.value)}
            rows={2}
            className="w-full border border-slate-300 rounded-xl p-2.5 text-xs bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
          />
        </div>
      </div>

      {/* SECTION 6: FINANCIAL SUMMARY & LEDGER IMPACT */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 flex flex-wrap items-center justify-between gap-6">
        <div>
          <span className="text-xs text-amber-400 font-bold uppercase tracking-wider block">
            B2B Package Financial Breakdown ({activeAgent.companyName})
          </span>
          <div className="text-2xl font-black text-white mt-1">
            SAR {grandTotalSAR.toLocaleString()}
            <span className="text-xs font-normal text-slate-400 ml-2">
              (~ PKR {(grandTotalSAR * 74).toLocaleString()})
            </span>
          </div>
          <div className="flex flex-wrap gap-4 text-xs text-slate-300 mt-2">
            <span>Hotel: SAR {estimatedHotelTotal.toLocaleString()}</span>
            <span>•</span>
            <span>Transport: SAR {estimatedTransportTotal.toLocaleString()}</span>
            <span>•</span>
            <span>Visa: SAR {estimatedVisaTotal.toLocaleString()}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
          >
            Cancel
          </button>

          {userRole === 'agent' ? (
            <button
              onClick={() => handleSave('draft')}
              className="px-6 py-3 text-xs font-black text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl shadow-lg transition cursor-pointer"
            >
              Save Draft Voucher ({voucherNo})
            </button>
          ) : (
            <button
              onClick={() => handleSave('approved')}
              className="px-6 py-3 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-lg transition cursor-pointer flex items-center gap-2"
            >
              <CheckCircle2 className="w-5 h-5" />
              Approve & Generate Official Voucher
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
