import QRCode from 'qrcode';
import { Mutamer, PaxType, HotelSector, Voucher } from '../types';

export async function generateVoucherQRCode(voucher: Voucher): Promise<string> {
  const payload = JSON.stringify({
    voucherNo: voucher.voucherNo,
    manualNo: voucher.manualNo,
    familyHead: voucher.familyHead,
    pax: voucher.paxCountText,
    agency: 'Ameer Hamza Travels & Tours',
    agent: voucher.agentCompany,
    status: voucher.status.toUpperCase(),
    approvedBy: voucher.approvedBy || 'Pending Central Review',
    sectorsCount: voucher.accommodations.length,
    hash: voucher.securityHash || 'AH-' + Math.random().toString(36).substring(2, 10).toUpperCase(),
  });

  try {
    return await QRCode.toDataURL(payload, {
      errorCorrectionLevel: 'M',
      margin: 1,
      width: 140,
      color: {
        dark: '#111827',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('QR Code generation error:', err);
    return '';
  }
}

export function calculateNights(checkin: string, checkout: string): number {
  if (!checkin || !checkout) return 1;
  try {
    const parseDate = (dStr: string) => {
      // Handles DD-MM-YY or DD-MM-YYYY or DD/MM/YYYY or YYYY-MM-DD
      const cleaned = dStr.trim();
      if (cleaned.includes('/')) {
        const parts = cleaned.split('/');
        if (parts.length === 3) {
          const day = parseInt(parts[0], 10);
          const month = parseInt(parts[1], 10) - 1;
          let year = parseInt(parts[2], 10);
          if (year < 100) year += 2000;
          return new Date(year, month, day);
        }
      } else if (cleaned.includes('-')) {
        const parts = cleaned.split('-');
        if (parts.length === 3) {
          if (parts[0].length === 4) {
            // YYYY-MM-DD
            return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
          } else {
            // DD-MM-YY
            const day = parseInt(parts[0], 10);
            const month = parseInt(parts[1], 10) - 1;
            let year = parseInt(parts[2], 10);
            if (year < 100) year += 2000;
            return new Date(year, month, day);
          }
        }
      }
      return new Date(dStr);
    };

    const d1 = parseDate(checkin);
    const d2 = parseDate(checkout);
    const diffTime = d2.getTime() - d1.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 1;
  } catch {
    return 1;
  }
}

export function summarizePax(mutamers: Mutamer[]): {
  adults: number;
  children: number;
  infants: number;
  totalPax: number;
  totalBeds: number;
  paxText: string;
} {
  let adults = 0;
  let children = 0;
  let infants = 0;
  let beds = 0;

  for (const m of mutamers) {
    if (m.paxType === 'Adult') adults++;
    else if (m.paxType === 'Child') children++;
    else if (m.paxType === 'Infant') infants++;

    if (m.bed === 'Yes') beds++;
  }

  const totalPax = mutamers.length;
  const paxText = `${totalPax} (A:${adults},C:${children},I:${infants}),Beds=${beds}`;

  return { adults, children, infants, totalPax, totalBeds: beds, paxText };
}

export function parseStandardCSV(csvText: string): {
  groupNo: string;
  groupName: string;
  mutamers: Mutamer[];
} {
  const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let groupNo = '1000';
  let groupName = 'AMEERHAMZAONLYACC';
  const mutamers: Mutamer[] = [];

  let isHeaderPassed = false;
  let sno = 1;

  for (const line of lines) {
    const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));

    if (cols[0]?.toLowerCase().includes('groupno')) {
      groupNo = cols[1] || '1000';
      continue;
    }
    if (cols[0]?.toLowerCase().includes('groupname')) {
      groupName = cols[1] || 'AMEERHAMZAONLYACC';
      continue;
    }

    if (cols[0]?.toLowerCase().includes('passportno') || cols[0]?.toLowerCase().includes('passport')) {
      isHeaderPassed = true;
      continue;
    }

    if (isHeaderPassed && cols.length >= 2 && cols[0]) {
      // PassportNo, First Name, Family Name, Birth Date, Gender
      const passportNo = cols[0];
      const firstName = cols[1] || '';
      const familyName = cols[2] || '';
      const birthDate = cols[3] || '';
      const gender = (cols[4] || 'Male').startsWith('F') ? 'F' : 'M';

      // Estimate Pax Type
      let paxType: PaxType = 'Adult';
      if (birthDate) {
        try {
          const parts = birthDate.split('/');
          if (parts.length === 3) {
            const bYear = parseInt(parts[2], 10);
            const currentYear = 2026;
            const age = currentYear - bYear;
            if (age < 2) paxType = 'Infant';
            else if (age < 12) paxType = 'Child';
          }
        } catch {}
      }

      const fullName = `${firstName} ${familyName}`.trim();

      mutamers.push({
        id: `m-std-${Date.now()}-${sno}`,
        sno: sno++,
        passportNo,
        firstName,
        familyName,
        mutamerName: fullName,
        gender,
        paxType,
        bed: paxType === 'Infant' ? 'No' : 'Yes',
        mofaNo: '4809' + Math.floor(100000 + Math.random() * 900000),
        grpNo: groupNo,
        visaNo: '9840' + Math.floor(1000 + Math.random() * 9000),
        pnr: 'PK-' + Math.floor(100 + Math.random() * 900),
        birthDate,
      });
    }
  }

  return { groupNo, groupName, mutamers };
}

export function parseNusukCSV(csvText: string): {
  groupNo: string;
  groupName: string;
  mutamers: Mutamer[];
} {
  const lines = csvText.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  let groupNo = 'NUSUK-2026';
  let groupName = 'NUSUK GROUP';
  const mutamers: Mutamer[] = [];

  let dataStarted = false;
  let sno = 1;

  for (const line of lines) {
    const cols = line.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
    if (cols.some(c => c.toLowerCase().includes('passport'))) {
      dataStarted = true;
      continue;
    }

    if (dataStarted && cols.length >= 3 && cols[2]) {
      // Group Code, Group Name, Passport No, Mutamer Full Name, Nationality, Gender, DOB, Visa No, MOFA No, PNR
      groupNo = cols[0] || groupNo;
      groupName = cols[1] || groupName;
      const passportNo = cols[2];
      const fullName = cols[3] || 'Mutamer ' + sno;
      const nationality = cols[4] || 'Pakistani';
      const gender = (cols[5] || '').toLowerCase().startsWith('f') ? 'F' : 'M';
      const dob = cols[6] || '';
      const visaNo = cols[7] || '98' + Math.floor(100000 + Math.random() * 900000);
      const mofaNo = cols[8] || '480' + Math.floor(1000000 + Math.random() * 9000000);
      const pnr = cols[9] || 'SV' + Math.floor(100 + Math.random() * 900);

      const nameParts = fullName.split(' ');
      const firstName = nameParts[0] || fullName;
      const familyName = nameParts.slice(1).join(' ') || firstName;

      mutamers.push({
        id: `m-nsk-${Date.now()}-${sno}`,
        sno: sno++,
        passportNo,
        firstName,
        familyName,
        mutamerName: fullName,
        gender,
        paxType: 'Adult',
        bed: 'Yes',
        mofaNo,
        grpNo: groupNo,
        visaNo,
        pnr,
        birthDate: dob,
        nationality,
      });
    }
  }

  return { groupNo, groupName, mutamers };
}
