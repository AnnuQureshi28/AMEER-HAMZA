import React, { useState } from 'react';
import {
  Voucher,
  B2BAgent,
  UserRole,
  HotelRate,
  VisaRate,
  TransportRate,
  VisaCompany,
  PilgrimGroup,
  LedgerEntry,
} from './types';
import {
  INITIAL_AGENTS,
  INITIAL_VISA_COMPANIES,
  INITIAL_PILGRIM_GROUPS,
  INITIAL_VOUCHERS,
  INITIAL_HOTEL_RATES,
  INITIAL_VISA_RATES,
  INITIAL_TRANSPORT_RATES,
  INITIAL_LEDGERS,
} from './data/initialData';
import { Header } from './components/Header';
import { VoucherList } from './components/VoucherList';
import { VoucherDocument } from './components/VoucherDocument';
import { VoucherCreator } from './components/VoucherCreator';
import { B2BLedgerView } from './components/B2BLedgerView';
import { RatesMasterView } from './components/RatesMasterView';
import { ImportPilgrimsView } from './components/ImportPilgrimsView';
import { QRVerificationModal } from './components/QRVerificationModal';

export default function App() {
  const [userRole, setUserRole] = useState<UserRole>('admin');
  const [agents, setAgents] = useState<B2BAgent[]>(INITIAL_AGENTS);
  const [selectedAgentId, setSelectedAgentId] = useState<string>('agent-alquds');
  const [visaCompanies, setVisaCompanies] = useState<VisaCompany[]>(INITIAL_VISA_COMPANIES);
  const [groups, setGroups] = useState<PilgrimGroup[]>(INITIAL_PILGRIM_GROUPS);
  const [vouchers, setVouchers] = useState<Voucher[]>(INITIAL_VOUCHERS);
  const [hotelRates, setHotelRates] = useState<HotelRate[]>(INITIAL_HOTEL_RATES);
  const [visaRates, setVisaRates] = useState<VisaRate[]>(INITIAL_VISA_RATES);
  const [transportRates, setTransportRates] = useState<TransportRate[]>(INITIAL_TRANSPORT_RATES);
  const [ledgers, setLedgers] = useState<LedgerEntry[]>(INITIAL_LEDGERS);

  // Active view
  const [currentTab, setCurrentTab] = useState<'vouchers' | 'create' | 'import' | 'ledgers' | 'rates'>('vouchers');
  const [viewingVoucher, setViewingVoucher] = useState<Voucher | null>(null);
  const [verifyingVoucher, setVerifyingVoucher] = useState<Voucher | null>(null);
  const [prefilledGroupForVoucher, setPrefilledGroupForVoucher] = useState<PilgrimGroup | null>(null);

  const currentAgent = agents.find((a) => a.id === selectedAgentId) || agents[0];

  const pendingApprovalsCount = vouchers.filter((v) => v.status === 'draft' || v.status === 'pending').length;

  // Approve a voucher (Admin only)
  const handleApproveVoucher = (voucherId: string) => {
    setVouchers((prev) =>
      prev.map((v) => {
        if (v.id === voucherId) {
          const updated: Voucher = {
            ...v,
            status: 'approved',
            approvedBy: 'Ameer Hamza Central Operations (Staff Auth ID: AH-901)',
            approvedDate:
              new Date().toLocaleDateString('en-GB') +
              ' ' +
              new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) +
              ' PKT',
            financials: {
              ...v.financials,
              ledgerPosted: true,
            },
          };

          // Post to ledger if not yet posted
          if (!v.financials.ledgerPosted) {
            const costInPKR = Math.round(v.financials.grandTotal * 74);
            const agentLedgerList = ledgers.filter((l) => l.agentId === v.agentId);
            const prevRunning = agentLedgerList[agentLedgerList.length - 1]?.runningBalancePKR || 0;
            const newEntry: LedgerEntry = {
              id: 'led-' + Date.now(),
              agentId: v.agentId,
              date: new Date().toISOString().split('T')[0],
              refNo: 'VCH-' + v.voucherNo,
              type: 'DEBIT',
              description: `Voucher ${v.voucherNo}: ${v.mutamers.length} Mutamers (${v.familyHead})`,
              amountPKR: costInPKR > 0 ? costInPKR : 300000,
              runningBalancePKR: prevRunning - (costInPKR > 0 ? costInPKR : 300000),
            };
            setLedgers((prevLedgers) => [...prevLedgers, newEntry]);
          }

          if (viewingVoucher?.id === voucherId) {
            setViewingVoucher(updated);
          }
          return updated;
        }
        return v;
      })
    );
  };

  // Reject a voucher
  const handleRejectVoucher = (voucherId: string, reason: string) => {
    setVouchers((prev) =>
      prev.map((v) => {
        if (v.id === voucherId) {
          const updated: Voucher = {
            ...v,
            status: 'rejected',
            rejectionReason: reason,
          };
          if (viewingVoucher?.id === voucherId) {
            setViewingVoucher(updated);
          }
          return updated;
        }
        return v;
      })
    );
  };

  // Save newly created voucher
  const handleSaveVoucher = (newVoucher: Voucher) => {
    setVouchers([newVoucher, ...vouchers]);

    // Update group status if matches groupNo
    if (newVoucher.groupNo) {
      setGroups((prev) =>
        prev.map((g) =>
          g.groupNo === newVoucher.groupNo
            ? { ...g, voucherStatus: newVoucher.status, voucherId: newVoucher.id }
            : g
        )
      );
    }

    if (newVoucher.status === 'approved' && newVoucher.financials.ledgerPosted) {
      const costInPKR = Math.round(newVoucher.financials.grandTotal * 74);
      const agentLedgerList = ledgers.filter((l) => l.agentId === newVoucher.agentId);
      const prevRunning = agentLedgerList[agentLedgerList.length - 1]?.runningBalancePKR || 0;
      const newEntry: LedgerEntry = {
        id: 'led-' + Date.now(),
        agentId: newVoucher.agentId,
        date: new Date().toISOString().split('T')[0],
        refNo: 'VCH-' + newVoucher.voucherNo,
        type: 'DEBIT',
        description: `Voucher ${newVoucher.voucherNo}: ${newVoucher.mutamers.length} Mutamers (${newVoucher.familyHead})`,
        amountPKR: costInPKR,
        runningBalancePKR: prevRunning - costInPKR,
      };
      setLedgers((prevLedgers) => [...prevLedgers, newEntry]);
    }

    // Open physical document view
    setViewingVoucher(newVoucher);
  };

  // Save new imported group
  const handleSaveGroup = (newGroup: PilgrimGroup) => {
    setGroups([newGroup, ...groups]);
  };

  // Create voucher for a specific group
  const handleCreateVoucherForGroup = (group: PilgrimGroup) => {
    setPrefilledGroupForVoucher(group);
    setSelectedAgentId(group.subAgentId);
    setCurrentTab('create');
  };

  // Add Visa Company
  const handleAddVisaCompany = (company: VisaCompany) => {
    setVisaCompanies([company, ...visaCompanies]);
  };

  // Add ledger entry
  const handleAddLedgerEntry = (entry: LedgerEntry) => {
    setLedgers((prev) => [...prev, entry]);
  };

  // Rates master actions
  const handleAddHotelRate = (rate: HotelRate) => {
    setHotelRates([rate, ...hotelRates]);
  };
  const handleAddVisaRate = (rate: VisaRate) => {
    setVisaRates([rate, ...visaRates]);
  };
  const handleAddTransportRate = (rate: TransportRate) => {
    setTransportRates([rate, ...transportRates]);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Top Header Bar */}
      <Header
        currentTab={currentTab}
        onTabChange={(tab) => {
          setViewingVoucher(null);
          if (tab !== 'create') {
            setPrefilledGroupForVoucher(null);
          }
          setCurrentTab(tab);
        }}
        userRole={userRole}
        onRoleChange={setUserRole}
        agents={agents}
        currentAgent={currentAgent}
        onAgentChange={setSelectedAgentId}
        pendingApprovalsCount={pendingApprovalsCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {/* If viewing a single voucher document for print or preview */}
        {viewingVoucher ? (
          <VoucherDocument
            voucher={viewingVoucher}
            onBack={() => setViewingVoucher(null)}
            onApprove={handleApproveVoucher}
            onReject={handleRejectVoucher}
            userRole={userRole}
            onVerifyClick={(v) => setVerifyingVoucher(v)}
          />
        ) : (
          <>
            {currentTab === 'vouchers' && (
              <VoucherList
                vouchers={vouchers}
                onSelectVoucher={(v) => setViewingVoucher(v)}
                onCreateNew={() => {
                  setPrefilledGroupForVoucher(null);
                  setCurrentTab('create');
                }}
                onApprove={handleApproveVoucher}
                onVerify={(v) => setVerifyingVoucher(v)}
                userRole={userRole}
                currentAgent={currentAgent}
              />
            )}

            {currentTab === 'create' && (
              <VoucherCreator
                currentAgent={currentAgent}
                userRole={userRole}
                allAgents={agents}
                visaCompanies={visaCompanies}
                groups={groups}
                prefilledGroup={prefilledGroupForVoucher}
                onSave={handleSaveVoucher}
                onCancel={() => {
                  setPrefilledGroupForVoucher(null);
                  setCurrentTab('vouchers');
                }}
                onOpenImporter={() => setCurrentTab('import')}
              />
            )}

            {currentTab === 'import' && (
              <ImportPilgrimsView
                agents={agents}
                visaCompanies={visaCompanies}
                groups={groups}
                onSaveGroup={handleSaveGroup}
                onCreateVoucherForGroup={handleCreateVoucherForGroup}
                onAddVisaCompany={handleAddVisaCompany}
              />
            )}

            {currentTab === 'ledgers' && (
              <B2BLedgerView
                agents={agents}
                selectedAgentId={selectedAgentId}
                onSelectAgent={setSelectedAgentId}
                ledgers={ledgers}
                onAddLedgerEntry={handleAddLedgerEntry}
                userRole={userRole}
              />
            )}

            {currentTab === 'rates' && (
              <RatesMasterView
                hotelRates={hotelRates}
                visaRates={visaRates}
                transportRates={transportRates}
                visaCompanies={visaCompanies}
                onAddHotelRate={handleAddHotelRate}
                onAddVisaRate={handleAddVisaRate}
                onAddTransportRate={handleAddTransportRate}
                onAddVisaCompany={handleAddVisaCompany}
                userRole={userRole}
              />
            )}
          </>
        )}
      </main>

      {/* Verification Certificate Modal */}
      <QRVerificationModal
        voucher={verifyingVoucher}
        isOpen={Boolean(verifyingVoucher)}
        onClose={() => setVerifyingVoucher(null)}
      />

      {/* Footer (No print) */}
      <footer className="no-print bg-slate-900 border-t border-slate-800 text-slate-400 py-6 text-xs text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">Ameer Hamza Travels & Tours</span>
            <span>•</span>
            <span>B2B Umrah & Hajj Operations Central Platform</span>
          </div>
          <div>
            KSA Visa Partners: Ziafa International / Bab Al-Umrah / Al-Deafah • Central Operations Multan
          </div>
        </div>
      </footer>
    </div>
  );
}
